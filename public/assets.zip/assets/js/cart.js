var notRequiredQtyAjaxClickonQtyBtn = true;
function getSelectedVariants(cartItems = [], checkDuplicate = true) {
    let selected = {};
    const productId = String($('.addToCartBtn').first().data('id') || '');

    $('.s-variant.active[data-type]').each(function() {
        const $variant = $(this);
        const type = String($variant.attr('data-type') || '').toLowerCase();
        const value = String($variant.attr('data-value') || '');

        if (type && value) {
            selected[type] = value;
        }
    });

    if (!checkDuplicate) {
        return selected;
    }

    const exists = cartItems.some(function(item) {
        if (String(item.productId) !== productId) {
            return false;
        }

        const selectedIds = getSelectedVariantIds();
        const existingIds = item.selectedVariantIds || [];
        if (selectedIds.length && existingIds.length) {
            return selectedIds.slice().sort().join(',') === existingIds.slice().sort().join(',');
        }

        return sameVariantSelection(item.selectedVariants, selected);
    });

    return exists ? null : selected;
}

function getSelectedVariantIds() {
    return $('.s-variant.active[data-type]').map(function() {
        return String($(this).attr('data-vid') || '');
    }).get().filter(Boolean);
}

function sameVariantSelection(first, second) {
    const firstEntries = Object.entries(first || {})
        .map(([key, value]) => [String(key).toLowerCase(), String(value)])
        .sort(([firstKey], [secondKey]) => firstKey.localeCompare(secondKey));
    const secondEntries = Object.entries(second || {})
        .map(([key, value]) => [String(key).toLowerCase(), String(value)])
        .sort(([firstKey], [secondKey]) => firstKey.localeCompare(secondKey));

    return JSON.stringify(firstEntries) === JSON.stringify(secondEntries);
}

function setAddToCartButtonState(button, isInCart) {
    const $button = $(button);
    $button.attr('data-cart-state', isInCart ? 'in-cart' : 'add');
    $button.find('span').first().text(isInCart ? 'GO TO CART' : 'ADD TO CART');
}

$(document).on('click', '.addToCartBtn', function() {
    const button = $(this);
    if (button.prop('disabled') || button.hasClass('disabled-action')) {
        return;
    }
    if (button.attr('data-cart-state') === 'in-cart') {
        window.location.href = viewCartUrl;
        return;
    }
    const productId = button.data('id');
    const quantity = parseInt($('#quantity').val(), 10) || 1;
    const selectedVariants = getSelectedVariants([], false);
    const selectedVariantIds = getSelectedVariantIds();
    const requiredVariantCount = parseInt(button.attr('data-variant-count'), 10) || 0;
    if (button.attr('data-variant-required') === 'true'
        && selectedVariantIds.length < requiredVariantCount) {
        showFlashMessage('Please select all product options.', 'error');
        return;
    }

    if (window.isLoggedIn) {
        button.prop('disabled', true);
        isLoginUser(productId, quantity, selectedVariants, null, null, selectedVariantIds, button);
        return;
    }

    const stock = parseInt(button.attr('data-stock'), 10);
    if (Number.isFinite(stock) && stock >= 0 && quantity > stock) {
        showFlashMessage(stock > 0
            ? 'Only ' + stock + ' item(s) are available.'
            : 'This product is out of stock.', 'error');
        return;
    }

    let cartItems;
    try {
        cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
        if (!Array.isArray(cartItems)) {
            cartItems = [];
        }
    } catch (error) {
        console.error('Unable to read guest cart.', error);
        showFlashMessage('Unable to access your cart. Please try again.', 'error');
        return;
    }

    const existingItem = cartItems.find(function(item) {
        if (String(item.productId) !== String(productId)) {
            return false;
        }

        const existingIds = item.selectedVariantIds || [];
        if (selectedVariantIds.length && existingIds.length) {
            return selectedVariantIds.slice().sort().join(',')
                === existingIds.slice().sort().join(',');
        }

        return sameVariantSelection(item.selectedVariants, selectedVariants);
    });
    const newQuantity = quantity;
    if (Number.isFinite(stock) && stock >= 0 && newQuantity > stock) {
        showFlashMessage('Only ' + stock + ' item(s) are available.', 'error');
        return;
    }

    if (existingItem) {
        existingItem.quantity = newQuantity;
    } else {
        cartItems.push({
            randomId: 'prod_' + Date.now() + '_' + Math.floor(Math.random() * 10000),
            productId: productId,
            name: button.data('name'),
            productType: button.data('producttype'),
            sku: button.data('sku'),
            slug: button.data('slug'),
            quantity: quantity,
            price: button.data('price'),
            sellingPrice: button.data('saleprice'),
            discountType: button.data('discounttype'),
            discountAmount: button.data('discount'),
            image: document.querySelector('.default-image')?.src || '',
            selectedVariants: selectedVariants,
            selectedVariantIds: selectedVariantIds,
            rawTaxArr: button.attr('data-tax-arr')
        });
    }

    try {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    } catch (error) {
        console.error('Unable to save guest cart.', error);
        showFlashMessage('Unable to save your cart. Please try again.', 'error');
        return;
    }

    setAddToCartButtonState(button, true);
    $('.center-main').text(cartItems.length);
    showFlashMessage("Product added to cart successfully");
});

$(document).ready(function () {
    if (!window.isLoggedIn) {
        // updateHeaderCart();
    }
});
// function openCartDropdown() {
//     let $wrapper = $('.cart-wrapper');
//     let $dropdown = $('.cart-dropdown');

//     if (!$wrapper.length || !$dropdown.length) {
//         console.log('Cart wrapper/dropdown not found');
//         return;
//     }

//     $wrapper.addClass('open active');
//     $dropdown.addClass('open active');

//     // Agar CSS display se hidden hai to force visible
//     $dropdown.css({
//         'display': 'block',
//         'visibility': 'visible',
//         'opacity': '1'
//     });

//     console.log('Cart dropdown opened');
// }
// function updateHeaderCart() {
//     let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
//     let $container = $('#headerCartItems');

//     if (!$container.length) {
//         console.log('#headerCartItems not found');
//         return;
//     }

//     $container.empty();

//     if (cartItems.length === 0) {
//         $container.html(`
//             <div class="empty-cart">
//                 Your cart is empty.
//             </div>
//         `);

//         $('#cartCount').text('0');
//         $('#cartTotal').text('₹0');

//         return;
//     }

//     let total = 0;

//     cartItems.slice(0, 2).forEach(function(item, index) {
//         let price = parseFloat(item.sellingPrice || 0);
//         let quantity = parseInt(item.quantity || 1);

//         total += price * quantity;

//         let productSlug = (item.name || '')
//             .toString()
//             .toLowerCase()
//             .trim()
//             .replace(/[^a-z0-9\s-]/g, '')
//             .replace(/\s+/g, '-')
//             .replace(/-+/g, '-');

//         let productUrl =
//             "{{ url('product/product') }}/" +
//             productSlug +
//             ".html/" +
//             item.sku;

//         let html = `
//             <div class="cart-item"
//                 data-randomid="${item.randomId}"
//                 data-index="${index}">

//                 <a href="${productUrl}">
//                     <img src="${item.image}" alt="${item.name}">
//                 </a>

//                 <div class="cart-info">
//                     <h5>${item.name}</h5>
//                     <span>Qty: ${quantity}</span>
//                     <strong>₹${price}</strong>
//                 </div>

//                 <button type="button"
//                     class="remove-item close-product"
//                     data-randomid="${item.randomId}"
//                     data-index="${index}">

//                     <span class="material-symbols-outlined">
//                         close
//                     </span>
//                 </button>
//             </div>
//         `;

//         $container.append(html);
//     });

//     $('#cartCount').text(cartItems.length);
//     $('#cartTotal').text('₹' + total.toFixed(0));

//     console.log('Header cart updated:', cartItems);
// }
displayCartItems(true); 
function displayCartItems(notRequiredQtyAjaxClickonQtyBtn) {
   
    let cartItems = [];
    cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    // let productListContainer = $('.productListContainer');
    // let productListCartPageContainer = $('.productListCartPageContainer');

    console.log("cart ITem ----",cartItems); 
    // productListContainer.empty();
    
    $('.center-main').html(cartItems.length);

    if (cartItems.length == 0) {
        $(".add-cart-footer").hide();
        // productListContainer.append(emptyCartImg);
        // productListCartPageContainer.append(emptyCartImg);
        $('.cart-collaterals').hide();
   } else {
        $(".add-cart-footer").show();
        $('.cart-collaterals').show();
    }

    var notRequiredQtyAjaxClickonQtyBtnNew = notRequiredQtyAjaxClickonQtyBtn;
    console.log(' before foreach notRequiredQtyAjaxClickonQtyBtn : ',notRequiredQtyAjaxClickonQtyBtn);
    console.log('cartItems : ',cartItems);
    var cartTotal = 0;
    // productListCartPageContainer.empty();

    
    cartItems.forEach(function (item, index) {
        let variants = item.selectedVariants || {};
        console.log("=======variants========",variants); 
        let product_sku = item.sku.toLowerCase();
        // console.log("-----variants-------",variants); 
        let variantHTML = '';
        for (const [key, value] of Object.entries(variants)) {
            if (value) {
                variantHTML += `<p class="s-text">${key.charAt(0).toUpperCase() + key.slice(1)}: ${value}</p>`;
            }
        }
        //  sku accoring to variant && product type 
        let variant_sku = product_sku.toLowerCase();
        if(item.productType==2){
            // variant_sku = product_sku + '_' + variants.colour.toLowerCase() + '_' + variants.size.toLowerCase();
            variant_sku = product_sku + '_' + variants['gemstone name'].toLowerCase() + '_' + variants.size.toLowerCase();
        }
        //  sku accoring to variant && product type 
        
        var is_out_stock = '';
        $.ajax({
            url: isOutOfStock,
            type: 'POST',
            async: false,
            cache: false,
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                product_id: item.productId,
                variant_sku: variant_sku,
            },
            success: function (response) {
                console.log(' is out od stock response :  ', response);
                if(response){
                    is_out_stock = 'Out Of Stock';
                }
                console.log(' is_out_stock :  ', is_out_stock);
            },
            error: function () {
            // alert('Failed to add to cart. Please try again.');
            }
        });
        //  product is out of stock 

        // get variant colour and size combo exact qty
        console.log('after notRequiredQtyAjaxClickonQtyBtnNew : ',notRequiredQtyAjaxClickonQtyBtnNew);
        if(notRequiredQtyAjaxClickonQtyBtnNew==true){
            let variant_sku = product_sku.toLowerCase();
            if(item.productType==2){
                // variant_sku = product_sku + '_' + variants.colour.toLowerCase() + '_' + variants.size.toLowerCase();
                variant_sku = product_sku + '_' + variants['gemstone name'].toLowerCase() + '_' + variants.size.toLowerCase();
            }
            //  sku accoring to variant && product type 

            var getExactVariantComboQty = 0;
            const originalHtmlMinus = $(".addToDecQtyBtn").html();
            const originalHtmlPlus = $(".addToNewQtyBtn").html();
            $.ajax({
                url: getVarientReaminingQty,
                type: 'POST',
                async: false,
                cache: false,
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    product_id: item.productId,
                    sku: variant_sku,
                },
                beforeSend: function(){
                    // $(".addToDecQtyBtn").attr("disableed",true).html(`
                    // <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                    // Processing...
                    // `);
                    //     $(".addToNewQtyBtn").attr("disableed",true).html(`
                    //     <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                    //     Processing...
                    // `);
                    
                // $(".addToDecQtyBtn").attr("disabled",true);
                // $(".addToNewQtyBtn").attr("disabled",true);
                $(".addToDecQtyBtn").css("pointer-events", "none");
                $(".addToNewQtyBtn").css("pointer-events", "none");
                },
                success: function (response) {
                    getExactVariantComboQty = response;
                    console.log('Add to cart ');
                    console.log('maxSellingQty 1 : ',maxSellingQty);
                    if(parseInt(maxSellingQty) > parseInt(getExactVariantComboQty) || parseInt(maxSellingQty)==0){
                        maxSellingQtyNew = getExactVariantComboQty;
                    } else {
                        maxSellingQtyNew = maxSellingQty;
                    }
                    console.log('getExactVariantComboQty : ',getExactVariantComboQty);
                    console.log('maxSellingQty 2 : ',maxSellingQty);
                    console.log('maxSellingQtyNew 3 : ',maxSellingQtyNew);

                    $(".addToDecQtyBtn").css("pointer-events", "auto");
                $(".addToNewQtyBtn").css("pointer-events", "auto");
                    $(".addToDecQtyBtn").html(originalHtmlMinus);
                    $(".addToNewQtyBtn").html(originalHtmlPlus);
                },
                error: function () {
                // alert('Failed to add to cart. Please try again.');
                }
            });
        }  else {
        }
        // get variant colour and size combo exact qty

        let sellingPrice = item.sellingPrice;
        // let discountAmount = item.discountAmount;
        let discountType = item.discountType;

        let discountAmount = parseFloat(item.discountAmount);

        if (Number.isInteger(discountAmount)) {
            discountAmount = discountAmount.toFixed(0); // integer show kare
        } else {
            discountAmount = discountAmount.toString(); // decimal as it is show kare
        }

        let discountText = '';
        if (discountType === 'flat') {
            discountText = `${Math.floor(discountAmount)} Rs Off`;
        } else if (discountType === 'percentage') {
            discountText = `${Math.floor(discountAmount)}% Off`;
        }

        let discountHTML = discountText ? `<span class="off-tag">${discountText}</span>` : '';


        if(is_out_stock !=''){
            var offer_tag = `<span class="offer-tag">Out Of Stock, Please remove it.</span>`;
        } else {
           var offer_tag =  `<span class="offer-tag"><i class="fa-regular fa-clock"></i> Limited time offer</span>`;
        }

        cartTotal += item.sellingPrice;
    });

    $('.cartTotalPopup').html(cartTotal);

    // localStorage.setItem('applied_coupon',[]);
    // localStorage.setItem('coupon_discount',0);
    if (!window.isLoggedIn) {
        priceCalculation();
    }
}

function decodeHtml(html) {
    var txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}

function priceCalculation() {
    let cartItems = [];
    cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    let totalQuantity = cartItems.reduce((sum, item) => {
        return sum + (parseInt(item.quantity) || 0);
    }, 0);

    let couponDiscountValue = parseFloat(couponDiscount) || 0;

    let totalMrp = 0;
    let totalDiscount = 0;
    let subtotal = 0;
    let totalTaxPrice = 0;
    let taxOption = 'inclusive';
    let taxRate = 0;
    let taxType = 'flat';

    cartItems.forEach(function(item) {
        let quantity = parseInt(item.quantity) || 1;
        let price = parseFloat(item.price) || 0;
        let sellingPrice = parseFloat(item.sellingPrice) || 0;

        totalMrp += price * quantity;
        totalDiscount += (price - sellingPrice) * quantity;
        subtotal += sellingPrice * quantity;

        if (item.tax_option) {
            taxOption = item.tax_option;
        }

        if (item.tax_rate !== undefined && item.tax_rate !== null) {
            taxRate = parseFloat(item.tax_rate) || taxRate;
        }

        if (item.tax_type) {
            taxType = item.tax_type;
        }
    });
    let grandTotal = subtotal - couponDiscountValue;

    if (grandTotal < 0) {
        grandTotal = 0;
    }
    totalTaxPrice = 0;
    cartItems.forEach(function(item) {
        let quantity = parseInt(item.quantity) || 1;
        let sellingPrice = parseFloat(item.sellingPrice) || 0;

        let itemTax = 0;

        let rawTaxArr = item.rawTaxArr || '';
        let taxArr = [];

        try {
            if (rawTaxArr) {
                if (Array.isArray(rawTaxArr)) {
                    taxArr = rawTaxArr;
                } else if (typeof rawTaxArr === 'string') {
                    let decodedJson = decodeHtml(rawTaxArr);
                    taxArr = JSON.parse(decodedJson) || [];
                }
            }
        } catch (error) {
            console.error('Tax JSON Parse Error:', error);
            taxArr = [];
        }
        let itemCouponDiscount = 0;

        if (couponDiscountValue > 0 && totalQuantity > 0) {
            itemCouponDiscount = couponDiscountValue / totalQuantity;
        }

        let netPrice = sellingPrice - itemCouponDiscount;

        if (netPrice < 0) {
            netPrice = 0;
        }

        taxArr.forEach(function(tax) {
            let currentTaxRate = 0;

            if (
                tax.tax_rate !== undefined &&
                tax.tax_rate !== null &&
                String(tax.tax_rate).toLowerCase() !== 'no tax'
            ) {
                currentTaxRate = parseFloat(tax.tax_rate) || 0;
            }
            if (tax.tax_type === 'flat') {

                taxOption = tax.tax_option || 'inclusive';
                taxType = 'flat';
                taxRate = currentTaxRate;

                if (taxOption === 'inclusive') {
                    itemTax = (netPrice * currentTaxRate) / 100;
                } else {
                    itemTax = (netPrice * currentTaxRate) / 100;
                }
            }
            else if (tax.tax_type === 'floating') {

                let taxFrom = parseFloat(tax.tax_from) || 0;
                let taxTo = parseFloat(tax.tax_to) || 0;

                if (netPrice >= taxFrom && netPrice <= taxTo) {

                    taxOption = tax.tax_option || 'inclusive';
                    taxType = 'floating';
                    taxRate = currentTaxRate;

                    if (taxOption === 'inclusive') {

                        let taxBase = 1 + (currentTaxRate / 100);

                        let basePrice = currentTaxRate > 0
                            ? netPrice / taxBase
                            : netPrice;

                        itemTax = netPrice - basePrice;

                    } else {

                        itemTax = (netPrice * currentTaxRate) / 100;
                    }
                }
            }
        });

        totalTaxPrice += itemTax * quantity;
    });

    let taxableAmount = grandTotal;
    if (taxOption === 'inclusive') {
        taxableAmount = grandTotal - totalTaxPrice;

        if (taxableAmount < 0) {
            taxableAmount = 0;
        }
    } else if (taxOption === 'exclusive') {
        taxableAmount = grandTotal;
    }
    let totalPayable = grandTotal;

    if (taxOption === 'exclusive') {
        totalPayable = grandTotal + totalTaxPrice;
    }

    $('.totalMRP .price-values').html(
        `₹${totalMrp.toFixed(2)}`
    );

    $('.discount .price-values').html(
        `₹${totalDiscount.toFixed(2)}`
    );

    $('.subtotal .price-values').html(
        `₹${subtotal.toFixed(2)}`
    );

    $('.grandTotal .price-values').html(
        `₹${grandTotal.toFixed(2)}`
    );

    $('.taxableAmount .price-values').html(
        `₹${taxableAmount.toFixed(2)}`
    );

    $('.totalGst .price-values').html(
        `₹${totalTaxPrice.toFixed(2)}`
    );

    $('.totalPayable .price-values').html(
        `₹${totalPayable.toFixed(2)}`
    );

    $('#totalMrp').html(`₹${totalMrp.toFixed(2)}`);
    $('#totalDiscount').html(`₹${totalDiscount.toFixed(2)}`);
    $('#subTotal').html(`₹${subtotal.toFixed(2)}`);
    $('#grandTotal').html(`₹${grandTotal.toFixed(2)}`);
    $('#taxableAmount').html(`₹${taxableAmount.toFixed(2)}`);
    $('#taxPrice').html(`₹${totalTaxPrice.toFixed(2)}`);

    $('.finalAmount').html(`₹${Math.floor(totalPayable)}`);

    if (totalPayable > 0) {
        $('.checkoutButton').removeClass('disabled-link');
        $('.btn_place_order').prop('disabled', false);
    } else {
        $('.checkoutButton').addClass('disabled-link');
        $('.btn_place_order').prop('disabled', true);
    }

    window.cartCalculation = {
        totalMRP: totalMrp,
        totalDiscount: totalDiscount,
        subtotal: subtotal,
        couponDiscount: couponDiscountValue,
        grandTotal: grandTotal,
        taxableAmount: taxableAmount,
        totalGst: totalTaxPrice,
        totalPayable: totalPayable,
        taxOption: taxOption,
        taxRate: taxRate,
        taxType: taxType
    };

    console.log('========== CART CALCULATION ==========');
    console.log(window.cartCalculation);

    return window.cartCalculation;
}


// document.addEventListener('click', function (e) {
//     const button = e.target.closest('.close-product');
//     if (!button) {
//         return;
//     }
//     e.preventDefault();
//     // Guest user → LocalStorage
//     if (!window.isCustomerLoggedIn) {
//         const index = parseInt(button.dataset.index);
//         let cartItems = JSON.parse(
//             localStorage.getItem('cartItems') || '[]'
//         );
//         if (cartItems[index]) {
//             cartItems.splice(index, 1);

//             localStorage.setItem(
//                 'cartItems',
//                 JSON.stringify(cartItems)
//             );
//             displayGuestCart();
//             showFlashMessage("Product removed from cart", "warning");
//         }
//         return;
//     }
//     // Logged-in user → Database
//     const cartId = button.dataset.cartid;

//     if (cartId) {
//         removeProductCartFromDB(cartId);
//     }

// }, true);



displayWishlistItem();
function displayWishlistItem() {
    let wishlistCount = (localStorage.getItem('wishlistCount') && localStorage.getItem('wishlistCount') != "undefined") ? JSON.parse(localStorage.getItem('wishlistCount')) : 0;
    $(".wishlist-count").html(wishlistCount);
}

$(document).off('click','.addToNewQtyBtn, .addToDecQtyBtn').on('click','.addToNewQtyBtn, .addToDecQtyBtn',function (e) {
        e.preventDefault();
        var input =$(this).closest('.input-increment').find('.quantityInputs');
        var randomId =input.data('randomid');
        if (window.isLoggedIn) {
            var productId =input.data('productid');
            var selectedVariants =input.data('variants') || {};
            var currentQty =parseInt(input.val()) || 1;
            var minQty =parseInt(input.attr('min')) || 1;
            var maxQty =parseInt(input.attr('max')) || 10;


            if ($(this).hasClass('addToNewQtyBtn') && currentQty < maxQty) {
                currentQty++;
            }
            else if ($(this).hasClass('addToDecQtyBtn') && currentQty > minQty) {
                currentQty--;
            }
            input.val(currentQty);
            localStorage.setItem('applied_coupon',[]);
            localStorage.setItem('coupon_discount',0);
            isLoginUser(productId,currentQty,selectedVariants);
            return;
        }

        var cartItems =JSON.parse(localStorage.getItem('cartItems')) || [];
        var existingItemIndex =
            cartItems.findIndex(function (item) {
                    return item.randomId == randomId;
                });
        if (existingItemIndex === -1) {
            return;
        }
        var currentQty =parseInt(cartItems[existingItemIndex].quantity);
        var minQty =parseInt(input.attr('min')) || 1;
        var maxQty =parseInt(input.attr('max')) || 10;


        if ($(this).hasClass('addToNewQtyBtn') && currentQty < maxQty) {
            currentQty++;
        }
        else if ($(this).hasClass('addToDecQtyBtn') && currentQty > minQty) {
            currentQty--;
        }


        localStorage.setItem('applied_coupon',[]);
        localStorage.setItem('coupon_discount',0);
        cartItems[existingItemIndex].quantity = currentQty;
        cartItems[existingItemIndex].total = parseFloat(cartItems[existingItemIndex].price) * currentQty;
        localStorage.setItem('cartItems',JSON.stringify(cartItems));
        console.log('Guest quantity updated');
        var notRequiredQtyAjaxClickonQtyBtn =false;
        displayCartItems(notRequiredQtyAjaxClickonQtyBtn);
    }
);

function isLoginUser(productId, quantity, selectedVariants, type = null, cartId = null, selectedVariantIds = [], button = null) {
    if (!window.isLoggedIn) {
        return;
    }

    $.ajax({
        url: addToCart,
        type: 'POST',
        data: {
            _token: $('meta[name="csrf-token"]').attr('content'),
            product_id: productId,
            quantity: quantity,
            selected_variants: selectedVariants,
            selected_variant_ids: selectedVariantIds,
            addType: type,
            cart_id: cartId
        },
        success: function(response) {
            if (!response.success) {
                showFlashMessage(response.message || "Unable to update cart.");
                return;
            }
            if (type === 'remove') {
                showFlashMessage("Product removed from cart","warning");
                return;
            }
            if (button && selectedVariantIds.length) {
                const selectedIds = selectedVariantIds.map(Number).sort((first, second) => first - second);
                const exists = (window.productCartVariantIds || []).some(function(ids) {
                    return ids.slice().map(Number).sort((first, second) => first - second).join(',')
                        === selectedIds.join(',');
                });
                if (!exists) {
                    window.productCartVariantIds = window.productCartVariantIds || [];
                    window.productCartVariantIds.push(selectedIds);
                }
            }
            setAddToCartButtonState(button || '.addToCartBtn', true);
            showFlashMessage("Product added to cart successfully");
        },
        error: function(xhr) {
            showFlashMessage(
                xhr.responseJSON?.message || "Unable to update cart. Please try again.",
                'error'
            );
        },
        complete: function() {
            if (button) {
                $(button).prop('disabled', false);
            }
        }
    });
}

$(document).on('click', '.view-more-link', function () {
    getCoupon()
});

function getCoupon() {
    $.post(getCouponUrl, {
        cart_items: JSON.parse(localStorage.getItem('cartItems')) || [],
        _token: $('meta[name="csrf-token"]').attr('content'),
    }, function (response) {
        if (response.status) {
            $(".offer-available").html(response.coupons.length + " Offers Available");
            $('#all_coupons').empty();
            $('#static_offers').empty();

            let offerCount = 0;
            console.log(response.coupons);
            response.coupons.forEach(function (coupon) {
                let disabled = coupon.is_applicable ? '' : 'apply-button-disabled';
                let reasonMsg = `<p class="text-danger small">${coupon.reason}</p>`;

                let html =
                    `<div class="coupan-box ${!coupon.is_applicable ? 'bg-light text-muted' : ''}">
                        <span class="tag-off">${coupon.discount_type === 'percentage' ? coupon.discount_value + '% off' : 'Flat ₹' + coupon.discount_value + ' off'}</span>
                        <div class="coupan-box-space">
                            <div class="coupan-box-inner">
                                <div class="cb-left">
                                    <h5>${coupon.code}</h5>
                                    <span>Save ₹${coupon.discount_amount}</span>
                                </div>
                                <div class="cb-right">
                                    <a class="apply-btn coupon-apply ${disabled}" data-code="${coupon.code}">Apply</a>
                                </div>
                            </div>
                            <p>${coupon.description}</p>
                            ${reasonMsg}
                        </div>
                    </div>`;
                ;
                $('#all_coupons').append(html);
            });

            let staticOffers = [];

            response.coupons.slice(0, 2).forEach(coupon => {
                staticOffers.push(coupon.description);
            });

            staticOffers.forEach(function (offerText) {
                let offerHtml =
                    `<p>
                        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink"
                            width="30" height="30" x="0" y="0" viewBox="0 0 512.003 512.003"
                            style="enable-background: new 0 0 512 512;" xml:space="preserve" class="">
                            <g>
                                <path
                                    d="M477.958 262.633a15.004 15.004 0 0 1 0-13.263l19.096-39.065c10.632-21.751 2.208-47.676-19.178-59.023l-38.41-20.38a15.005 15.005 0 0 1-7.796-10.729l-7.512-42.829c-4.183-23.846-26.241-39.87-50.208-36.479l-43.053 6.09a15.004 15.004 0 0 1-12.613-4.099l-31.251-30.232c-17.401-16.834-44.661-16.835-62.061 0L193.72 42.859a15.01 15.01 0 0 1-12.613 4.099l-43.053-6.09c-23.975-3.393-46.025 12.633-50.208 36.479l-7.512 42.827a15.008 15.008 0 0 1-7.795 10.73l-38.41 20.38c-21.386 11.346-29.81 37.273-19.178 59.024l19.095 39.064a15.004 15.004 0 0 1 0 13.263L14.95 301.699c-10.632 21.751-2.208 47.676 19.178 59.023l38.41 20.38a15.005 15.005 0 0 1 7.796 10.729l7.512 42.829c3.808 21.708 22.422 36.932 43.815 36.93 2.107 0 4.245-.148 6.394-.452l43.053-6.09a15 15 0 0 1 12.613 4.099l31.251 30.232c8.702 8.418 19.864 12.626 31.03 12.625 11.163-.001 22.332-4.209 31.03-12.625l31.252-30.232c3.372-3.261 7.968-4.751 12.613-4.099l43.053 6.09c23.978 3.392 46.025-12.633 50.208-36.479l7.513-42.827a15.008 15.008 0 0 1 7.795-10.73l38.41-20.38c21.386-11.346 29.81-37.273 19.178-59.024l-19.096-39.065zm-13.923 72.002-38.41 20.38c-12.246 6.499-20.645 18.057-23.04 31.713l-7.512 42.828a15.038 15.038 0 0 1-16.987 12.342l-43.053-6.09c-13.73-1.945-27.316 2.474-37.281 12.113L266.5 478.152a15.04 15.04 0 0 1-20.997 0l-31.251-30.232c-8.422-8.147-19.432-12.562-30.926-12.562-2.106 0-4.229.148-6.355.449l-43.053 6.09a15.042 15.042 0 0 1-16.987-12.342l-7.513-42.829c-2.396-13.656-10.794-25.215-23.041-31.712l-38.41-20.38a15.037 15.037 0 0 1-6.489-19.969L60.574 275.6c6.088-12.456 6.088-26.742 0-39.198l-19.096-39.065a15.037 15.037 0 0 1 6.489-19.969l38.41-20.38c12.246-6.499 20.645-18.057 23.04-31.713l7.512-42.828a15.038 15.038 0 0 1 16.987-12.342l43.053 6.09c13.725 1.943 27.316-2.474 37.281-12.113l31.252-30.232a15.04 15.04 0 0 1 20.997 0l31.251 30.232c9.965 9.64 23.554 14.056 37.281 12.113l43.053-6.09a15.04 15.04 0 0 1 16.987 12.342l7.512 42.829c2.396 13.656 10.794 25.215 23.041 31.712l38.41 20.38a15.037 15.037 0 0 1 6.489 19.969l-19.096 39.064c-6.088 12.455-6.088 26.743 0 39.198l19.096 39.064a15.039 15.039 0 0 1-6.488 19.972z"
                                    fill="#fc2424" opacity="1" data-original="#000000" class=""></path>
                                <path
                                    d="M363.886 148.116c-5.765-5.766-15.115-5.766-20.881 0l-194.889 194.89c-5.766 5.766-5.766 15.115 0 20.881a14.72 14.72 0 0 0 10.44 4.325c3.778 0 7.558-1.441 10.44-4.325l194.889-194.889c5.768-5.767 5.768-15.115.001-20.882zM196.941 123.116c-29.852 0-54.139 24.287-54.139 54.139s24.287 54.139 54.139 54.139 54.139-24.287 54.139-54.139-24.287-54.139-54.139-54.139zm0 78.747c-13.569 0-24.608-11.039-24.608-24.609 0-13.569 11.039-24.608 24.608-24.608s24.609 11.039 24.609 24.608c-.001 13.57-11.04 24.609-24.609 24.609zM315.061 280.61c-29.852 0-54.139 24.287-54.139 54.139s24.287 54.139 54.139 54.139c29.852 0 54.139-24.287 54.139-54.139s-24.287-54.139-54.139-54.139zm0 78.747c-13.569 0-24.609-11.039-24.609-24.608s11.039-24.608 24.609-24.608c13.569 0 24.608 11.039 24.608 24.608s-11.039 24.608-24.608 24.608z"
                                    fill="#fc2424" opacity="1" data-original="#000000" class=""></path>
                            </g>
                        </svg>
                        ${offerText}
                    </p>`
                    ;
                $('#static_offers').append(offerHtml);
                offerCount++;
            });

            if (response.coupons.length > 2) {
                $('#total_offers').text(`+${response.coupons.length} Offers`);
            }
        } else {
        }
    });
}
